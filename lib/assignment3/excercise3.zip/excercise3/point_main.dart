import 'package:amit_training/assignment3/excercise3/point.dart';

void main(){
  var point = Point(5, 50);
  point.display();
  point.move(50, 500);
  point.display();
}