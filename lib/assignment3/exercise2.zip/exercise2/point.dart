class Point{
  double? _x;
  double? _y;
  Point(this._x, this._y);
  getPointX(){
    return this._x;
  }
  getPointY(){
    return this._y;
  }
}