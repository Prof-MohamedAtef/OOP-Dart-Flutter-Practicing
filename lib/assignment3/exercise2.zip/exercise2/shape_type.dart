enum ShapeType{
  SQUARE,
  RECTANGLE,
  UN_DEFINED
}